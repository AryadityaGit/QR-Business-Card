import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { QrCode, Play } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="gradient-primary text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Digital Visiting Cards<br/>
            <span className="text-blue-200">That Actually Work</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
            Create QR-based visiting cards that work offline, update in real-time, and never get lost. 
            No servers required, just scan and connect.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/editor">
              <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-gray-100">
                <QrCode className="mr-2 h-5 w-5" />
                Create Your Card
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-primary">
              <Play className="mr-2 h-5 w-5" />
              Watch Demo
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
