import { QrCode, Zap, RefreshCw, Smartphone, TrendingUp, Palette } from "lucide-react";

const features = [
  {
    icon: QrCode,
    title: "Instant QR Generation",
    description: "Generate professional QR codes instantly. No design skills needed - just add your info and share.",
    bgColor: "bg-primary",
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Static hosting means your cards load instantly. No servers, no delays, just pure speed.",
    bgColor: "bg-accent",
  },
  {
    icon: RefreshCw,
    title: "Real-time Updates",
    description: "Update your card anytime. Changes reflect immediately the next time someone scans your QR.",
    bgColor: "bg-secondary",
  },
  {
    icon: Smartphone,
    title: "Mobile Optimized",
    description: "Perfect on every device. Your cards look professional whether viewed on phone, tablet, or desktop.",
    bgColor: "bg-orange-500",
  },
  {
    icon: TrendingUp,
    title: "Analytics Dashboard",
    description: "Track scans, monitor engagement, and understand your networking reach with detailed analytics.",
    bgColor: "bg-green-500",
  },
  {
    icon: Palette,
    title: "Multiple Templates",
    description: "Choose from professional templates or customize your own. Make your card uniquely yours.",
    bgColor: "bg-purple-500",
  },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Everything You Need for Digital Networking
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional features designed for modern networking without the complexity
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-shadow">
                <div className={`w-12 h-12 ${feature.bgColor} rounded-lg flex items-center justify-center mb-6`}>
                  <Icon className="text-white h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
