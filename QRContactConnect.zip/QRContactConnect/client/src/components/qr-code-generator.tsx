import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, QrCode } from "lucide-react";

interface QRCodeGeneratorProps {
  cardId: number;
  className?: string;
}

export default function QRCodeGenerator({ cardId, className = "" }: QRCodeGeneratorProps) {
  const [isDownloading, setIsDownloading] = useState(false);

  const downloadQRCode = async () => {
    setIsDownloading(true);
    try {
      const response = await fetch(`/api/cards/${cardId}/qr`);
      if (response.ok) {
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `card-${cardId}-qr.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Failed to download QR code:', error);
    } finally {
      setIsDownloading(false);
    }
  };

  const qrCodeUrl = `/api/cards/${cardId}/qr`;

  return (
    <div className={`text-center ${className}`}>
      <div className="inline-block bg-white p-4 rounded-xl shadow-lg">
        <img 
          src={qrCodeUrl} 
          alt="QR Code"
          className="w-32 h-32 rounded-lg"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.style.display = 'none';
            target.nextElementSibling?.classList.remove('hidden');
          }}
        />
        <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center hidden">
          <QrCode className="h-12 w-12 text-gray-400" />
        </div>
      </div>
      <p className="text-sm text-gray-600 mt-2">Your QR Code</p>
      <Button 
        onClick={downloadQRCode} 
        variant="outline" 
        size="sm" 
        className="mt-2"
        disabled={isDownloading}
      >
        <Download className="mr-1 h-4 w-4" />
        {isDownloading ? "Downloading..." : "Download PNG"}
      </Button>
    </div>
  );
}
