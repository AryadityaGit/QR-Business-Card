import { Card as CardType } from "@shared/schema";
import { Phone, Mail, Globe, User } from "lucide-react";
import { FaLinkedin } from "react-icons/fa";
import { Button } from "@/components/ui/button";

interface CardPreviewProps {
  card: Partial<CardType>;
  className?: string;
}

const templateStyles = {
  professional: "bg-gradient-to-r from-primary to-blue-600",
  creative: "bg-gradient-to-r from-secondary to-purple-600",
  modern: "bg-gradient-to-r from-accent to-green-600",
};

export default function CardPreview({ card, className = "" }: CardPreviewProps) {
  const template = (card.template as keyof typeof templateStyles) || "professional";
  const headerStyle = templateStyles[template];

  const handleSaveContact = () => {
    // Create vCard data
    const vCard = `BEGIN:VCARD
VERSION:3.0
FN:${card.name || 'Contact'}
ORG:${card.company || ''}
TITLE:${card.jobTitle || ''}
TEL:${card.phone || ''}
EMAIL:${card.email || ''}
URL:${card.website || ''}
END:VCARD`;

    // Create and download vCard file
    const blob = new Blob([vCard], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name || 'contact'}.vcf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`mx-auto max-w-sm ${className}`}>
      <div className="bg-gray-800 rounded-3xl p-2">
        <div className="bg-white rounded-2xl overflow-hidden">
          {/* Card Header */}
          <div className={`${headerStyle} text-white p-8 text-center`}>
            <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full mx-auto mb-4 flex items-center justify-center">
              <User className="h-8 w-8" />
            </div>
            <h4 className="text-xl font-bold mb-1">{card.name || "Your Name"}</h4>
            <p className="text-blue-100 text-sm">{card.jobTitle || "Your Job Title"}</p>
            <p className="text-blue-200 text-xs">{card.company || "Your Company"}</p>
          </div>
          
          {/* Card Content */}
          <div className="p-6 space-y-4">
            {card.phone && (
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-primary" />
                <span className="text-sm text-gray-600">{card.phone}</span>
              </div>
            )}
            {card.email && (
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-primary" />
                <span className="text-sm text-gray-600">{card.email}</span>
              </div>
            )}
            {card.linkedin && (
              <div className="flex items-center space-x-3">
                <FaLinkedin className="h-5 w-5 text-primary" />
                <span className="text-sm text-gray-600">LinkedIn Profile</span>
              </div>
            )}
            {card.website && (
              <div className="flex items-center space-x-3">
                <Globe className="h-5 w-5 text-primary" />
                <span className="text-sm text-gray-600">Personal Website</span>
              </div>
            )}
            
            <div className="pt-4 border-t border-gray-200">
              <Button onClick={handleSaveContact} className="w-full">
                Save Contact
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
