import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { QrCode, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location === path;

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <QrCode className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-primary">QRCard</h1>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="/#features">
                <a className="text-gray-600 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">
                  Features
                </a>
              </Link>
              <Link href="/#pricing">
                <a className="text-gray-600 hover:text-primary px-3 py-2 rounded-md text-sm font-medium">
                  Pricing
                </a>
              </Link>
              <Link href="/dashboard">
                <a className={`px-3 py-2 rounded-md text-sm font-medium ${
                  isActive("/dashboard") 
                    ? "text-primary bg-primary/10" 
                    : "text-gray-600 hover:text-primary"
                }`}>
                  Dashboard
                </a>
              </Link>
              <Link href="/editor">
                <Button className="ml-2">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <div className="flex flex-col space-y-2">
              <Link href="/#features">
                <a className="text-gray-600 hover:text-primary px-3 py-2 rounded-md text-sm font-medium block">
                  Features
                </a>
              </Link>
              <Link href="/#pricing">
                <a className="text-gray-600 hover:text-primary px-3 py-2 rounded-md text-sm font-medium block">
                  Pricing
                </a>
              </Link>
              <Link href="/dashboard">
                <a className={`px-3 py-2 rounded-md text-sm font-medium block ${
                  isActive("/dashboard") 
                    ? "text-primary bg-primary/10" 
                    : "text-gray-600 hover:text-primary"
                }`}>
                  Dashboard
                </a>
              </Link>
              <Link href="/editor">
                <Button className="mx-3 mt-2">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
