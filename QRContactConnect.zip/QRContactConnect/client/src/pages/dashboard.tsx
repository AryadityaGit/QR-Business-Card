import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Navigation from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, BarChart3, Download, QrCode } from "lucide-react";
import { Card as CardType } from "@shared/schema";
import QRCodeGenerator from "@/components/qr-code-generator";

export default function Dashboard() {
  const { data: cards, isLoading } = useQuery<CardType[]>({
    queryKey: ["/api/cards"],
  });

  const totalScans = cards?.reduce((sum, card) => sum + card.scanCount, 0) || 0;
  const activeCards = cards?.filter(card => card.isActive).length || 0;
  const thisWeekScans = cards?.reduce((sum, card) => {
    // Simplified calculation - in real app, would use proper date filtering
    return sum + Math.floor(card.scanCount * 0.2);
  }, 0) || 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64 mb-4"></div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="bg-gray-800 text-white rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold mb-2">Your Dashboard</h1>
              <p className="text-gray-300">Manage your digital visiting cards</p>
            </div>
            <Link href="/editor">
              <Button className="bg-primary hover:bg-blue-700">
                <Plus className="mr-2 h-5 w-5" />
                New Card
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-primary">{totalScans}</div>
              <div className="text-sm text-gray-600">Total Scans</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-accent">{activeCards}</div>
              <div className="text-sm text-gray-600">Active Cards</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-secondary">{thisWeekScans}</div>
              <div className="text-sm text-gray-600">This Week</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-orange-600">24%</div>
              <div className="text-sm text-gray-600">Contact Rate</div>
            </CardContent>
          </Card>
        </div>

        {/* Cards List */}
        <Card>
          <CardHeader>
            <CardTitle>Your Cards</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!cards || cards.length === 0 ? (
              <div className="text-center py-12">
                <QrCode className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No cards yet</h3>
                <p className="text-gray-600 mb-4">Create your first digital visiting card to get started.</p>
                <Link href="/editor">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Your First Card
                  </Button>
                </Link>
              </div>
            ) : (
              cards.map((card) => (
                <div key={card.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                        <QrCode className="text-white h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{card.title}</h3>
                        <p className="text-sm text-gray-600">{card.jobTitle}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <Badge variant={card.isActive ? "default" : "secondary"}>
                            {card.isActive ? "Active" : "Draft"}
                          </Badge>
                          <span className="text-xs text-gray-500">{card.scanCount} scans</span>
                          <span className="text-xs text-gray-500">
                            Last: {card.lastScanned ? new Date(card.lastScanned).toRelativeTimeString() : "Never"}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Link href={`/editor/${card.id}`}>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </Link>
                      <Button variant="ghost" size="sm">
                        <BarChart3 className="h-4 w-4" />
                      </Button>
                      <QRCodeGenerator cardId={card.id} />
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
