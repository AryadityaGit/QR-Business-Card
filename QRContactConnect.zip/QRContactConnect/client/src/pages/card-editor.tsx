import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Navigation from "@/components/navigation";
import CardPreview from "@/components/card-preview";
import QRCodeGenerator from "@/components/qr-code-generator";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertCardSchema, type Card as CardType } from "@shared/schema";

interface CardEditorProps {
  params?: { id: string };
}

const templates = [
  { value: "professional", label: "Professional", color: "from-primary to-blue-600" },
  { value: "creative", label: "Creative", color: "from-secondary to-purple-600" },
  { value: "modern", label: "Modern", color: "from-accent to-green-600" },
];

export default function CardEditor({ params }: CardEditorProps) {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const cardId = params?.id ? parseInt(params.id) : null;
  const isEditing = cardId !== null;

  const { data: card, isLoading } = useQuery<CardType>({
    queryKey: ["/api/cards", cardId],
    enabled: isEditing,
  });

  const form = useForm({
    resolver: zodResolver(insertCardSchema),
    defaultValues: {
      title: "",
      name: "",
      jobTitle: "",
      company: "",
      phone: "",
      email: "",
      website: "",
      linkedin: "",
      bio: "",
      template: "professional",
      isActive: true,
    },
  });

  // Update form when card data is loaded
  useEffect(() => {
    if (card) {
      form.reset({
        title: card.title,
        name: card.name,
        jobTitle: card.jobTitle || "",
        company: card.company || "",
        phone: card.phone || "",
        email: card.email || "",
        website: card.website || "",
        linkedin: card.linkedin || "",
        bio: card.bio || "",
        template: card.template,
        isActive: card.isActive,
      });
    }
  }, [card, form]);

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/cards", data),
    onSuccess: async (response) => {
      const newCard = await response.json();
      await queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      toast({ title: "Card created successfully!" });
      navigate(`/editor/${newCard.id}`);
    },
    onError: () => {
      toast({ title: "Failed to create card", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/cards/${cardId}`, data),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/cards", cardId] });
      toast({ title: "Card updated successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to update card", variant: "destructive" });
    },
  });

  const onSubmit = (data: any) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const watchedValues = form.watch();

  if (isLoading && isEditing) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64 mb-8"></div>
            <div className="grid lg:grid-cols-2 gap-12">
              <div className="space-y-6">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="h-16 bg-gray-200 rounded"></div>
                ))}
              </div>
              <div className="h-96 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            {isEditing ? "Edit Card" : "Create New Card"}
          </h1>
          <p className="text-gray-600 mt-2">
            {isEditing ? "Update your digital visiting card" : "Create your digital visiting card with our intuitive editor"}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Editor Panel */}
          <Card>
            <CardHeader>
              <CardTitle>Card Details</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Card Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Professional Card" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="jobTitle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Job Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Chief Executive Officer" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company</FormLabel>
                        <FormControl>
                          <Input placeholder="TechCorp Industries" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input type="tel" placeholder="+1 (555) 123-4567" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="john@techcorp.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="linkedin"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>LinkedIn Profile</FormLabel>
                        <FormControl>
                          <Input type="url" placeholder="https://linkedin.com/in/johndoe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="website"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Website</FormLabel>
                        <FormControl>
                          <Input type="url" placeholder="https://johndoe.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="template"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Card Template</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a template" />
                            </SelectTrigger>
                            <SelectContent>
                              {templates.map((template) => (
                                <SelectItem key={template.value} value={template.value}>
                                  {template.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex gap-4">
                    <Button 
                      type="submit" 
                      className="flex-1"
                      disabled={createMutation.isPending || updateMutation.isPending}
                    >
                      {createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                    <Button type="button" variant="outline">
                      Preview
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Preview Panel */}
          <div className="lg:sticky lg:top-8 space-y-8">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Live Preview</h3>
              <CardPreview card={watchedValues} />
            </div>

            {/* QR Code Preview */}
            {isEditing && cardId && (
              <QRCodeGenerator cardId={cardId} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
