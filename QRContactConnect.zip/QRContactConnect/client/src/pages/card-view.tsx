import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card as CardType } from "@shared/schema";
import CardPreview from "@/components/card-preview";
import { Button } from "@/components/ui/button";
import { QrCode, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface CardViewProps {
  params: { id: string };
}

export default function CardView({ params }: CardViewProps) {
  const cardId = parseInt(params.id);

  const { data: card, isLoading, error } = useQuery<CardType>({
    queryKey: ["/api/cards", cardId],
  });

  const trackScanMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/cards/${cardId}/scan`, {}),
    retry: false,
  });

  // Track the scan when the component mounts
  useEffect(() => {
    if (cardId && !trackScanMutation.data) {
      trackScanMutation.mutate();
    }
  }, [cardId]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <QrCode className="h-12 w-12 text-gray-400 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading card...</p>
        </div>
      </div>
    );
  }

  if (error || !card) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <QrCode className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Card Not Found</h1>
          <p className="text-gray-600 mb-6">
            This digital visiting card doesn't exist or has been removed.
          </p>
          <Link href="/">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  if (!card.isActive) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <QrCode className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Card Unavailable</h1>
          <p className="text-gray-600 mb-6">
            This digital visiting card is currently inactive.
          </p>
          <Link href="/">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
          </Link>
          <div className="flex items-center space-x-2">
            <QrCode className="h-5 w-5 text-primary" />
            <span className="font-medium text-gray-900">QRCard</span>
          </div>
        </div>
      </div>

      {/* Card Content */}
      <div className="py-8 px-4">
        <CardPreview card={card} />
        
        {/* Bio Section */}
        {card.bio && (
          <div className="max-w-sm mx-auto mt-8">
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-3">About</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{card.bio}</p>
            </div>
          </div>
        )}

        {/* Powered by */}
        <div className="text-center mt-8">
          <Link href="/">
            <p className="text-sm text-gray-500">
              Powered by <span className="text-primary font-medium">QRCard</span>
            </p>
          </Link>
        </div>
      </div>
    </div>
  );
}
