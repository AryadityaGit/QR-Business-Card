import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  name: text("name").notNull(),
  jobTitle: text("job_title"),
  company: text("company"),
  phone: text("phone"),
  email: text("email"),
  website: text("website"),
  linkedin: text("linkedin"),
  bio: text("bio"),
  template: text("template").notNull().default("professional"),
  isActive: boolean("is_active").notNull().default(true),
  scanCount: integer("scan_count").notNull().default(0),
  lastScanned: timestamp("last_scanned"),
  qrCodeUrl: text("qr_code_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const scans = pgTable("scans", {
  id: serial("id").primaryKey(),
  cardId: integer("card_id").references(() => cards.id).notNull(),
  scannedAt: timestamp("scanned_at").defaultNow().notNull(),
  userAgent: text("user_agent"),
  ipAddress: text("ip_address"),
});

export const insertCardSchema = createInsertSchema(cards).omit({
  id: true,
  scanCount: true,
  lastScanned: true,
  qrCodeUrl: true,
  createdAt: true,
  updatedAt: true,
});

export const insertScanSchema = createInsertSchema(scans).omit({
  id: true,
  scannedAt: true,
});

export type InsertCard = z.infer<typeof insertCardSchema>;
export type Card = typeof cards.$inferSelect;
export type InsertScan = z.infer<typeof insertScanSchema>;
export type Scan = typeof scans.$inferSelect;
