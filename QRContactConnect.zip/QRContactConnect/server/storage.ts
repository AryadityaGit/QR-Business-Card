import { cards, scans, type Card, type InsertCard, type Scan, type InsertScan } from "@shared/schema";

export interface IStorage {
  // Card operations
  getCard(id: number): Promise<Card | undefined>;
  getAllCards(): Promise<Card[]>;
  createCard(card: InsertCard): Promise<Card>;
  updateCard(id: number, card: Partial<InsertCard>): Promise<Card | undefined>;
  deleteCard(id: number): Promise<boolean>;
  incrementScanCount(id: number): Promise<void>;
  
  // Scan operations
  createScan(scan: InsertScan): Promise<Scan>;
  getCardScans(cardId: number): Promise<Scan[]>;
  getRecentScans(cardId: number, limit?: number): Promise<Scan[]>;
}

export class MemStorage implements IStorage {
  private cards: Map<number, Card>;
  private scans: Map<number, Scan>;
  private currentCardId: number;
  private currentScanId: number;

  constructor() {
    this.cards = new Map();
    this.scans = new Map();
    this.currentCardId = 1;
    this.currentScanId = 1;
  }

  async getCard(id: number): Promise<Card | undefined> {
    return this.cards.get(id);
  }

  async getAllCards(): Promise<Card[]> {
    return Array.from(this.cards.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createCard(insertCard: InsertCard): Promise<Card> {
    const id = this.currentCardId++;
    const now = new Date();
    const card: Card = {
      ...insertCard,
      id,
      scanCount: 0,
      lastScanned: null,
      qrCodeUrl: `/api/cards/${id}/qr`,
      createdAt: now,
      updatedAt: now,
    };
    this.cards.set(id, card);
    return card;
  }

  async updateCard(id: number, updateCard: Partial<InsertCard>): Promise<Card | undefined> {
    const existingCard = this.cards.get(id);
    if (!existingCard) return undefined;

    const updatedCard: Card = {
      ...existingCard,
      ...updateCard,
      updatedAt: new Date(),
    };
    this.cards.set(id, updatedCard);
    return updatedCard;
  }

  async deleteCard(id: number): Promise<boolean> {
    const deleted = this.cards.delete(id);
    // Also delete associated scans
    const cardScans = Array.from(this.scans.entries()).filter(([_, scan]) => scan.cardId === id);
    cardScans.forEach(([scanId]) => this.scans.delete(scanId));
    return deleted;
  }

  async incrementScanCount(id: number): Promise<void> {
    const card = this.cards.get(id);
    if (card) {
      const updatedCard: Card = {
        ...card,
        scanCount: card.scanCount + 1,
        lastScanned: new Date(),
      };
      this.cards.set(id, updatedCard);
    }
  }

  async createScan(insertScan: InsertScan): Promise<Scan> {
    const id = this.currentScanId++;
    const scan: Scan = {
      ...insertScan,
      id,
      scannedAt: new Date(),
    };
    this.scans.set(id, scan);
    
    // Increment the card's scan count
    await this.incrementScanCount(insertScan.cardId);
    
    return scan;
  }

  async getCardScans(cardId: number): Promise<Scan[]> {
    return Array.from(this.scans.values())
      .filter(scan => scan.cardId === cardId)
      .sort((a, b) => new Date(b.scannedAt).getTime() - new Date(a.scannedAt).getTime());
  }

  async getRecentScans(cardId: number, limit: number = 10): Promise<Scan[]> {
    const cardScans = await this.getCardScans(cardId);
    return cardScans.slice(0, limit);
  }
}

export const storage = new MemStorage();
