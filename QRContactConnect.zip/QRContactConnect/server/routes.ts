import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCardSchema, insertScanSchema } from "@shared/schema";
import QRCode from "qrcode";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all cards
  app.get("/api/cards", async (req, res) => {
    try {
      const cards = await storage.getAllCards();
      res.json(cards);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cards" });
    }
  });

  // Get a specific card
  app.get("/api/cards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const card = await storage.getCard(id);
      
      if (!card) {
        return res.status(404).json({ error: "Card not found" });
      }

      res.json(card);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch card" });
    }
  });

  // Create a new card
  app.post("/api/cards", async (req, res) => {
    try {
      const validatedData = insertCardSchema.parse(req.body);
      const card = await storage.createCard(validatedData);
      res.status(201).json(card);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create card" });
      }
    }
  });

  // Update a card
  app.put("/api/cards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCardSchema.partial().parse(req.body);
      const card = await storage.updateCard(id, validatedData);
      
      if (!card) {
        return res.status(404).json({ error: "Card not found" });
      }

      res.json(card);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to update card" });
      }
    }
  });

  // Delete a card
  app.delete("/api/cards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteCard(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Card not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete card" });
    }
  });

  // Generate QR code for a card
  app.get("/api/cards/:id/qr", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const card = await storage.getCard(id);
      
      if (!card) {
        return res.status(404).json({ error: "Card not found" });
      }

      const cardUrl = `${req.protocol}://${req.get('host')}/card/${id}`;
      const qrCodeBuffer = await QRCode.toBuffer(cardUrl, {
        type: 'png',
        width: 256,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });

      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', `attachment; filename="card-${id}-qr.png"`);
      res.send(qrCodeBuffer);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate QR code" });
    }
  });

  // Track card scan
  app.post("/api/cards/:id/scan", async (req, res) => {
    try {
      const cardId = parseInt(req.params.id);
      const card = await storage.getCard(cardId);
      
      if (!card) {
        return res.status(404).json({ error: "Card not found" });
      }

      const scanData = {
        cardId,
        userAgent: req.get('User-Agent') || null,
        ipAddress: req.ip || null,
      };

      const scan = await storage.createScan(scanData);
      res.status(201).json(scan);
    } catch (error) {
      res.status(500).json({ error: "Failed to track scan" });
    }
  });

  // Get card analytics
  app.get("/api/cards/:id/analytics", async (req, res) => {
    try {
      const cardId = parseInt(req.params.id);
      const card = await storage.getCard(cardId);
      
      if (!card) {
        return res.status(404).json({ error: "Card not found" });
      }

      const scans = await storage.getCardScans(cardId);
      const recentScans = await storage.getRecentScans(cardId, 10);

      // Calculate analytics
      const today = new Date();
      const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

      const scansThisWeek = scans.filter(scan => new Date(scan.scannedAt) >= weekAgo).length;
      const scansThisMonth = scans.filter(scan => new Date(scan.scannedAt) >= monthAgo).length;

      res.json({
        totalScans: card.scanCount,
        scansThisWeek,
        scansThisMonth,
        lastScanned: card.lastScanned,
        recentScans,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
